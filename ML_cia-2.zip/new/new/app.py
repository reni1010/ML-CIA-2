from flask import Flask, request, \
    render_template
import mysql.connector as sql
app = Flask(__name__)
import pickle

model = pickle.load(open('model.pkl','rb'))

@app.route("/")
def main():
    return render_template("login.html")

@app.route("/login",methods=["GET","POST"])
def login():
    con=sql.connect(user='root', password='Karthic@2206*',host='localhost',database='login')
    cur=con.cursor()

    username = request.form['username']
    password = request.form['password']
    cur.execute('select * from details')
    t=cur.fetchone()
    print(t[0],t[1])
    # Check if the username exists and the password matches
    if username ==t[0] and password==t[1]:
        return render_template("index.html")

    else:
        return render_template("login.html")



@app.route("/predict", methods=['post'])
def pred():
    features = [float(i) 
                for i in 
                (request.form.values())]
    pred = model.predict([features])
    if pred[0]==0:
        ans='malignant'
    else:
        ans='bening'
    return render_template("success.html",
                           data=ans)

if __name__=='__main__':
    app.run(host='localhost',port=5000,debug=True)
