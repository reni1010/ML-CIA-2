# -*- coding: utf-8 -*-
"""
Created on Tue Mar 21 11:48:28 2023

@author: HP
"""
import pandas as pd

data = pd.read_excel('hiring.xlsx')

x = data.iloc[:,:-1].values
y = data.iloc[:,-1].values

from sklearn.linear_model import LinearRegression
regression = LinearRegression()

regression.fit(x,y)

#print(regression.predict([[3,6,9]]))

#%%
import pickle

pickle.dump(regression,open('model.pkl','wb'))









